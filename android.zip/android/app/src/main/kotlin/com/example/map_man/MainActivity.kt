package com.az.tos.mapman

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
